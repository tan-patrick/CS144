This example contains a simple utility class to simplify opening database
connections in Java applications, such as the one you will write to build
your Lucene index. 

To build and run the sample code, use the "run" ant target inside
the directory with build.xml by typing "ant run".



need itemID, Name, category, description (search through union of name, category, description) (need to store itemID and Name)
longitude and latitude will be done in the spatial index