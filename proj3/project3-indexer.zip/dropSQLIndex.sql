DROP INDEX locations ON ItemLocations;
DROP TABLE IF EXISTS ItemLocations;